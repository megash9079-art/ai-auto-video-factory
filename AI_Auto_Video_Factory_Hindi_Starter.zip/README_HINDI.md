# AI Auto Video Factory — Hindi Starter Project

यह मोबाइल से सेटअप करने योग्य शुरुआती प्रोजेक्ट है। यह रोज़ 3 हिंदी motivational/knowledge Shorts के लिए वीडियो फ़ाइलें बनाता है और GitHub Actions में शेड्यूल पर चल सकता है।

## ज़रूरी सच्चाई
- यह starter अभी **वीडियो बनाता है**, लेकिन Instagram/Facebook/YouTube पर अपने-आप प्रकाशित नहीं करता।
- ऑटो-पब्लिश के लिए हर प्लेटफ़ॉर्म का आधिकारिक API, अकाउंट अनुमति, OAuth/access tokens और सुरक्षित secrets सेट करना पड़ता है।
- Instagram publishing आम तौर पर Professional account और सही Meta/Page setup मांगता है। YouTube upload के लिए Google OAuth/API setup चाहिए।
- पासवर्ड या access token किसी को चैट में न भेजें और कोड में सीधे न लिखें।
- GitHub Actions की free limits/availability बदल सकती हैं; रोज़ाना चलने की गारंटी नहीं।

## फोन से शुरू करने के आसान चरण
1. GitHub पर नया **Public repository** बनाएँ, नाम `ai-auto-video-factory` रखें।
2. इस ZIP की सारी फाइलें repository में upload करें, folder structure वैसा ही रहने दें।
3. `quotes.json` में अपने हिंदी विचार जोड़ें।
4. GitHub में **Actions** टैब खोलें और workflow enable करें।
5. `Actions` → `Generate daily Hindi videos` → `Run workflow` से परीक्षण करें।
6. रन पूरा होने पर workflow के Artifacts में `daily-hindi-videos` ZIP मिलेगा। उसे डाउनलोड करके वीडियो देखें।

## रोज़ 3 वीडियो कैसे बनेंगे?
Workflow हर दिन UTC 03:30 पर (भारत में लगभग सुबह 9 बजे) चलता है और 3 vertical MP4 बनाने की कोशिश करता है। समय GitHub पर लोड के कारण आगे-पीछे हो सकता है।

## लोकल टेस्ट
Python 3.11+, FFmpeg और dependencies चाहिए:
```bash
pip install -r requirements.txt
python generate_videos.py
```

## अगला चरण: ऑटो-पब्लिश
1. YouTube Data API project + OAuth credentials सेट करें।
2. Meta developer app और Instagram Professional/Page publishing permissions सेट करें।
3. tokens को GitHub repository के Settings → Secrets and variables → Actions में रखें।
4. प्रत्येक platform के लिए publishing adapter बनाकर पहले test account/private/unpublished mode में जाँचें।
यह starter जानबूझकर कोई fake API key या login bypass शामिल नहीं करता।
