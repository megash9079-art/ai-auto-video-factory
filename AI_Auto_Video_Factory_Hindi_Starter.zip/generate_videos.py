import json, os, random, subprocess, textwrap
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
from gtts import gTTS

ROOT = Path(__file__).parent
OUT = ROOT / "output"
OUT.mkdir(exist_ok=True)
W, H = 720, 1280
FONT_PATHS = [
    "/usr/share/fonts/truetype/noto/NotoSansDevanagari-Regular.ttf",
    "/usr/share/fonts/truetype/noto/NotoSansDevanagariUI-Regular.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
]
def font(size):
    for p in FONT_PATHS:
        if os.path.exists(p):
            return ImageFont.truetype(p, size)
    return ImageFont.load_default()

def wrap_by_width(draw, text, fnt, max_width):
    words, lines, line = text.split(), [], ""
    for word in words:
        trial = (line + " " + word).strip()
        if draw.textbbox((0,0), trial, font=fnt)[2] <= max_width:
            line = trial
        else:
            if line: lines.append(line)
            line = word
    if line: lines.append(line)
    return lines

def make_card(item, index, path):
    im = Image.new("RGB", (W,H))
    px = im.load()
    palettes = [((12,25,65),(104,42,120)), ((4,75,84),(22,27,75)), ((91,35,25),(22,22,52))]
    c1,c2 = palettes[index % len(palettes)]
    for y in range(H):
        t = y/(H-1)
        c = tuple(int(c1[k]*(1-t)+c2[k]*t) for k in range(3))
        for x in range(W): px[x,y] = c
    d = ImageDraw.Draw(im)
    d.rounded_rectangle((46,70,W-46,H-70), radius=34, outline=(255,220,140), width=3)
    d.text((W//2,150), "AAJ KI SEEKH  •  HINDI", font=font(28), fill=(255,220,140), anchor="mm")
    title = item.get("title","आज की सीख")
    d.text((W//2,270), title, font=font(48), fill="white", anchor="mm", stroke_width=1, stroke_fill=(20,20,30))
    lines = wrap_by_width(d, item["text"], font(45), W-130)
    y = 490
    for line in lines:
        d.text((W//2,y), line, font=font(45), fill="white", anchor="mm", stroke_width=1, stroke_fill=(20,20,30))
        y += 72
    d.text((W//2,H-190), "रोज़ सीखें • रोज़ आगे बढ़ें", font=font(26), fill=(255,220,140), anchor="mm")
    d.text((W//2,H-135), "Follow for more", font=font(23), fill="white", anchor="mm")
    im.save(path, quality=95)

def main():
    items = json.loads((ROOT/"quotes.json").read_text(encoding="utf-8"))
    # Rotate content predictably each day; no random duplicate selection within the run.
    from datetime import date
    offset = date.today().toordinal() % len(items)
    chosen = [items[(offset+i) % len(items)] for i in range(min(3,len(items)))]
    if len(chosen) < 3:
        chosen = (chosen * 3)[:3]
    for i,item in enumerate(chosen,1):
        image_path = OUT / f"video_{i}.png"
        audio_path = OUT / f"voice_{i}.mp3"
        video_path = OUT / f"motivational_{i}.mp4"
        make_card(item, i-1, image_path)
        # Hindi TTS uses an online service, so this step needs internet access.
        gTTS(text=item["text"], lang="hi").save(str(audio_path))
        subprocess.run([
            "ffmpeg","-y","-loop","1","-i",str(image_path),"-i",str(audio_path),
            "-vf","scale=720:1280,format=yuv420p","-c:v","libx264","-tune","stillimage",
            "-c:a","aac","-b:a","128k","-shortest","-movflags","+faststart",str(video_path)
        ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        (OUT/f"caption_{i}.txt").write_text(
            f'{item.get("caption","")}\n\n{item.get("tags","")}', encoding="utf-8")
        print(f"Created {video_path.name}")
    print("Done. Check output/ for 3 MP4 videos and captions.")

if __name__ == "__main__":
    main()
